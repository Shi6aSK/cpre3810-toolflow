------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- ImmGen.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for
-- 
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity ImmGen is
   port(i_instr : in std_logic_vector(31 downto 0);
        o_imm   : out std_logic_vector(31 downto 0));
end ImmGen;

architecture behavioral of ImmGen is
   signal s_opcode : std_logic_vector(6 downto 0);
   signal s_imm_i  : std_logic_vector(31 downto 0);
   signal s_imm_s  : std_logic_vector(31 downto 0);
   signal s_imm_b  : std_logic_vector(31 downto 0);
   signal s_imm_u  : std_logic_vector(31 downto 0);
   signal s_imm_j  : std_logic_vector(31 downto 0);
begin
   s_opcode <= i_instr(6 downto 0);
   
   ------------------------------------------------------------------------------
   -- I-Type Immediate (ADDI, ANDI, ORI, XORI, SLTI, SLTIU, LW, JALR, etc.)
   -- Sign-extended from bits [31:20]
   ------------------------------------------------------------------------------
   s_imm_i <= std_logic_vector(resize(signed(i_instr(31 downto 20)), 32));
   
   ------------------------------------------------------------------------------
   -- S-Type Immediate (SW, SH, SB)
   -- imm[11:5] = instr[31:25]
   -- imm[4:0]  = instr[11:7]
   -- Sign-extended
   ------------------------------------------------------------------------------
   s_imm_s <= std_logic_vector(
               resize(
                  signed(i_instr(31 downto 25) & i_instr(11 downto 7)),
                  32));
   
   ------------------------------------------------------------------------------
   -- B-Type Immediate (BEQ, BNE, BLT, BGE, BLTU, BGEU)
   -- imm[12]   = instr[31]
   -- imm[11]   = instr[7]
   -- imm[10:5] = instr[30:25]
   -- imm[4:1]  = instr[11:8]
   -- imm[0]    = 0 (branches are 2-byte aligned)
   -- Sign-extended
   ------------------------------------------------------------------------------
   s_imm_b <= std_logic_vector(
               resize(
                  signed(i_instr(31) &
                         i_instr(7) &
                         i_instr(30 downto 25) &
                         i_instr(11 downto 8) &
                         '0'),
                  32));
   
   ------------------------------------------------------------------------------
   -- U-Type Immediate (LUI, AUIPC)
   -- imm[31:12] = instr[31:12]
   -- imm[11:0]  = 0
   ------------------------------------------------------------------------------
   s_imm_u <= i_instr(31 downto 12) & x"000";
   
   ------------------------------------------------------------------------------
   -- J-Type Immediate (JAL)
   -- imm[20]    = instr[31]
   -- imm[19:12] = instr[19:12]
   -- imm[11]    = instr[20]
   -- imm[10:1]  = instr[30:21]
   -- imm[0]     = 0 (jumps are 2-byte aligned)
   -- Sign-extended
   ------------------------------------------------------------------------------
   s_imm_j <= std_logic_vector(
               resize(
                  signed(i_instr(31) &
                         i_instr(19 downto 12) &
                         i_instr(20) &
                         i_instr(30 downto 21) &
                         '0'),
                  32));
   
   -- Select immediate based on opcode
   with s_opcode select
      o_imm <= s_imm_i when "0010011",   -- I-type ALU (ADDI, ANDI, ORI, etc.)
               s_imm_i when "0000011",   -- Loads (LW, LH, LB, LBU, LHU)
               s_imm_i when "1100111",   -- JALR
               s_imm_s when "0100011",   -- Stores (SW, SH, SB)
               s_imm_b when "1100011",   -- Branches
               s_imm_u when "0110111",   -- LUI
               s_imm_u when "0010111",   -- AUIPC
               s_imm_j when "1101111",   -- JAL
               (others => '0') when others;
end behavioral;