-------------------------------------------------------------------------
-- Chingyam Yeung
-- Department of Electrical and Computer Engineering
-- Iowa State University
-------------------------------------------------------------------------

-- barrelshifter.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: This file contains an implementation of a Barrel Shifter
--
-- NOTES:
-- 10/21/2025
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

entity BarrelShifter is
  generic(N : integer := 32); -- Generic of type integer for input/output data width. Default value is 32.
  port(i_S          : in std_logic_vector(4 downto 0);
       i_Data       : in std_logic_vector(N-1 downto 0);
       i_Dir        : in std_logic; --'0' right shift, '1' left shift
       i_Arith      : in std_logic; --'0'= logical, '1' = arithmetic
       o_Output     : out std_logic_vector(N-1 downto 0));
end BarrelShifter;

architecture structural of BarrelShifter is

  component mux2t1_N is
    port(i_S  : in std_logic;
         i_D0 : in std_logic_vector(N-1 downto 0);
         i_D1 : in std_logic_vector(N-1 downto 0);
         o_O  : out std_logic_vector(N-1 downto 0));
  end component;

  signal s1,s2,s3,s4,s5 : std_logic_vector(31 downto 0); --Five output signals of each mux stage
  signal Fill : std_logic;
  signal D1shift1, D1shift2, D1shift3, D1shift4, D1shift5 : std_logic_vector(31 downto 0);

begin

  -------------------------------------------------------------------------
  -- Fill bit for arithmetic right shift
  -------------------------------------------------------------------------
  Fill <= i_Data(31) when (i_Dir = '0' and i_Arith = '1') else '0';

  -------------------------------------------------------------------------
  -- Shift by 1
  -------------------------------------------------------------------------
  D1shift1 <= ( i_Data(30 downto 0)&'0') when i_Dir = '1'   -- Left shift
              else (Fill & i_Data(31 downto 1) );              -- Right shift

  
  -------------------------------------------------------------------------
  -- Mux chain for each shift stage
  -------------------------------------------------------------------------
  shifter1: mux2t1_N
    port map(i_S => i_S(0),
             i_D0 => i_Data,
             i_D1 => D1shift1,
             o_O  => s1);
  -------------------------------------------------------------------------
  -- Shift by 2
  -------------------------------------------------------------------------
  D1shift2 <= (s1(29 downto 0) & "00") when i_Dir = '1'       
              else ((Fill & Fill) & s1(31 downto 2) );         

  shifter2: mux2t1_N
    port map(i_S => i_S(1),
             i_D0 => s1,
             i_D1 => D1shift2,
             o_O  => s2);
  -------------------------------------------------------------------------
  -- Shift by 4
  -------------------------------------------------------------------------
  D1shift3 <= ( s2(27 downto 0) &"0000") when i_Dir = '1'     
              else ((Fill & Fill & Fill & Fill)&s2(31 downto 4)  ); 


  shifter3: mux2t1_N
    port map(i_S => i_S(2),
             i_D0 => s2,
             i_D1 => D1shift3,
             o_O  => s3);
  -------------------------------------------------------------------------
  -- Shift by 8
  -------------------------------------------------------------------------
  D1shift4 <= (  s3( 23 downto 0)&"00000000") when i_Dir = '1' 
              else ((Fill & Fill & Fill & Fill & Fill & Fill & Fill & Fill)&s3( 31 downto 8) 
                    ); 


  shifter4: mux2t1_N
    port map(i_S => i_S(3),
             i_D0 => s3,
             i_D1 => D1shift4,
             o_O  => s4);
  -------------------------------------------------------------------------
  -- Shift by 16
  -------------------------------------------------------------------------
  D1shift5 <= ( s4(15 downto 0)& "0000000000000000") when i_Dir = '1' 
              else ( (Fill & Fill & Fill & Fill & Fill & Fill & Fill & Fill &
                     Fill & Fill & Fill & Fill & Fill & Fill & Fill & Fill)&s4(31 downto 16) 
                   ); 


  shifter5: mux2t1_N
    port map(i_S => i_S(4),
             i_D0 => s4,
             i_D1 => D1shift5,
             o_O  => s5);

  -------------------------------------------------------------------------
  -- Final output
  -------------------------------------------------------------------------
  o_Output <= s5;

end structural;

