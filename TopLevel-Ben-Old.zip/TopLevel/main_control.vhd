-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- main_control.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for the main control unit
-- of the RISC-V style single cycle processor, determines instruction
-- types based on the 7 bit opcode of the 32 bit instructions.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

entity main_control is
   port(i_opcode   : in std_logic_vector(6 downto 0);
        o_RegWrite : out std_logic;
        o_ALUSrc   : out std_logic;
        o_MemRead  : out std_logic;
        o_MemWrite : out std_logic;
        o_MemtoReg : out std_logic_vector(1 downto 0);
        o_Branch   : out std_logic;
        o_JAL      : out std_logic;
        o_JALR     : out std_logic;
        o_AUIPC    : out std_logic;
        o_Halt     : out std_logic;
        o_ALUOp    : out std_logic_vector(2 downto 0));
end main_control;

architecture structure of main_control is
begin
   process(i_opcode)
   begin
      -- Default values
      o_RegWrite <= '0';
      o_ALUSrc   <= '0';
      o_MemRead  <= '0';
      o_MemWrite <= '0';
      o_MemtoReg <= "00";
      o_Branch   <= '0';
      o_JAL      <= '0';
      o_JALR     <= '0';
      o_AUIPC    <= '0';
      o_Halt     <= '0';
      o_ALUOp    <= "000";

      case i_opcode is
         when "0110011" =>   -- R-Type (add, sub, and, or, xor, slt, sltu, sll, srl, sra)
            o_RegWrite <= '1';
            o_ALUOp    <= "010";
            o_MemtoReg <= "00";   -- ALU result
            
         when "0010011" =>   -- I-Type ALU (addi, andi, ori, xori, slti, sltiu, slli, srli, srai)
            o_RegWrite <= '1';
            o_ALUSrc   <= '1';
            o_ALUOp    <= "011";
            o_MemtoReg <= "00";   -- ALU result
            
         when "0000011" =>   -- Load (lw, lb, lh, lbu, lhu)
            o_RegWrite <= '1';
            o_ALUSrc   <= '1';
            o_MemRead  <= '1';
            o_MemtoReg <= "01";   -- Memory data
            o_ALUOp    <= "000";
            
         when "0100011" =>   -- Store (sw, sb, sh)
            o_ALUSrc   <= '1';
            o_MemWrite <= '1';
            o_ALUOp    <= "000";
            
         when "1100011" =>   -- Branch (beq, bne, blt, bge, bltu, bgeu)
            o_Branch   <= '1';
            o_ALUOp    <= "110";
            
         when "1101111" =>   -- JAL
            o_RegWrite <= '1';
            o_JAL      <= '1';
            o_MemtoReg <= "10";   -- PC+4
            o_ALUOp    <= "000";
            
         when "1100111" =>   -- JALR
            o_RegWrite <= '1';
            o_JALR     <= '1';
            o_ALUSrc   <= '1';
            o_MemtoReg <= "10";   -- PC+4
            o_ALUOp    <= "000";
            
         when "0110111" =>   -- LUI
            o_RegWrite <= '1';
            o_ALUSrc   <= '1';
            o_ALUOp    <= "111";
            o_MemtoReg <= "00";   -- ALU result (pass immediate)
            
         when "0010111" =>   -- AUIPC
            o_RegWrite <= '1';
            o_AUIPC    <= '1';
            o_ALUSrc   <= '1';
            o_ALUOp    <= "000";
            o_MemtoReg <= "11";   -- AUIPC result (PC + immediate)
            
         when "1110011" =>   -- SYSTEM (ECALL, WFI, etc.)
            -- o_Halt is handled at top level by checking full instruction
            null;  -- Do nothing here
            
         when others =>
            null;
      end case;
   end process;
end structure;
