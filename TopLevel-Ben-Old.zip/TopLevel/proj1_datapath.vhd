-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- proj1_datapath.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for
-- 
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity proj1_datapath is
   generic(N : integer := 32);
   port(i_CLK        : in std_logic;
        i_RST        : in std_logic;
        i_RegWE      : in std_logic;
        i_RD         : in std_logic_vector(4 downto 0);
        i_RS1        : in std_logic_vector(4 downto 0);
        i_RS2        : in std_logic_vector(4 downto 0);
        i_RegWrData  : in std_logic_vector(N-1 downto 0);
        i_ALUCtrl    : in std_logic_vector(3 downto 0);
        i_ALUSrc     : in std_logic;
        i_ImmExt     : in std_logic_vector(N-1 downto 0);
        o_RS1_Data   : out std_logic_vector(N-1 downto 0);
        o_RS2_Data   : out std_logic_vector(N-1 downto 0);
        o_ALU_Result : out std_logic_vector(N-1 downto 0);
        o_ALU_Zero   : out std_logic;
        o_Overflow   : out std_logic);  -- ADDED: Overflow output
end proj1_datapath;

architecture structural of proj1_datapath is

   component regFile
      port(i_CLK   : in std_logic;
           i_RST   : in std_logic;
           i_WE    : in std_logic;
           i_ADDR  : in std_logic_vector(4 downto 0);
           i_DATA  : in std_logic_vector(31 downto 0);
           i_RS1   : in std_logic_vector(4 downto 0);
           i_RS2   : in std_logic_vector(4 downto 0);
           o_RS1   : out std_logic_vector(31 downto 0);
           o_RS2   : out std_logic_vector(31 downto 0));
   end component;

   component mux2t1_N is
      generic(N : integer := 32);
      port(i_S  : in std_logic;
           i_D0 : in std_logic_vector(N-1 downto 0);
           i_D1 : in std_logic_vector(N-1 downto 0);
           o_O  : out std_logic_vector(N-1 downto 0));
   end component;

   component ALU_RISCV is
      port(i_opA      : in std_logic_vector(31 downto 0);
           i_opB      : in std_logic_vector(31 downto 0);
           i_ALUCtrl  : in std_logic_vector(3 downto 0);
           o_Result   : out std_logic_vector(31 downto 0);
           o_Zero     : out std_logic;
           o_Overflow : out std_logic);
      end component;

   signal rs1_data  : std_logic_vector(31 downto 0);
   signal rs2_data  : std_logic_vector(31 downto 0);
   signal alu_y     : std_logic_vector(31 downto 0);
   signal alu_result : std_logic_vector(31 downto 0);
   signal alu_zero  : std_logic;
   signal alu_ovfl  : std_logic;  -- ADDED: Internal overflow signal

begin

   -- Register File
   REGF: regFile
      port map(i_CLK  => i_CLK,
               i_RST  => i_RST,
               i_WE   => i_RegWE,
               i_ADDR => i_RD,
               i_DATA => i_RegWrData,
               i_RS1  => i_RS1,
               i_RS2  => i_RS2,
               o_RS1  => rs1_data,
               o_RS2  => rs2_data);

   -- MUX for ALU operand B (Register vs Immediate)
   MUX_ALU_SRC: mux2t1_N
      generic map(N => 32)
      port map(i_S  => i_ALUSrc,
               i_D0 => rs2_data,
               i_D1 => i_ImmExt,
               o_O  => alu_y);

   -- ALU
   ALU: ALU_RISCV
      port map(i_opA     => rs1_data,
               i_opB     => alu_y,
               i_ALUCtrl => i_ALUCtrl,
               o_Result  => alu_result,
               o_Zero    => alu_zero,
               o_Overflow => alu_ovfl);  -- CHANGED: Connect to internal signal

   -- Outputs
   o_RS1_Data   <= rs1_data;
   o_RS2_Data   <= rs2_data;
   o_ALU_Result <= alu_result;
   o_ALU_Zero   <= alu_zero;
   o_Overflow   <= alu_ovfl;  -- ADDED: Output overflow

end structural;