-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 381
-- Iowa State University
-------------------------------------------------------------------------

-- full_adder.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file contains an implementation of a structural 
-- full adder for two 1-bit inputs.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity full_adder is
     port(i_N0    : in std_logic;
          i_N1    : in std_logic;
          i_Carry : in std_logic;
          o_Sum   : out std_logic;
          o_Carry : out std_logic);
end full_adder;

architecture structural of full_adder is
     component xorg2
          port(i_A   : in std_logic;
	       i_B   : in std_logic;
               o_F   : out std_logic);
     end component;

     component andg2
	  port(i_A   : in std_logic;
               i_B   : in std_logic;
	       o_F   : out std_logic);
     end component;

     component org2
          port(i_A   : in std_logic;
               i_B   : in std_logic;
               o_F   : out std_logic);
     end component;
     
     signal xor1_out                     : std_logic;
     signal and1_out, and2_out, and3_out : std_logic;
     signal or1_out                      : std_logic;
begin
    --XOR of Number 0 and Number 1 as xor1
    xor1: xorg2 
       port map(i_A => i_N0, 
                i_B => i_N1, 
                o_F => xor1_out);

    --XOR of xor1 and Cin as Sum
    xor2: xorg2 
       port map(i_A => xor1_out, 
                i_B => i_Carry, 
                o_F => o_Sum);

    --AND gates for Cout
    --N0 and N1
    and1: andg2
       port map(i_A => i_N0,
                i_B => i_N1,
                o_F => and1_out);
    --N0 and Cin
    and2: andg2
       port map(i_A => i_N0,
                i_B => i_Carry,
                o_F => and2_out);
    --N1 and Cin
    and3: andg2
       port map(i_A => i_N1,
                i_B => i_Carry,
                o_F => and3_out);
    --OR gates for Cout
    --and1 and and2
    or1: org2
       port map(i_A => and1_out,
                i_B => and2_out,
                o_F => or1_out);
    --and3 and or1 goes to Cout
    or2: org2
       port map(i_A => and3_out,
                i_B => or1_out,
                o_F => o_Carry);

end structural;