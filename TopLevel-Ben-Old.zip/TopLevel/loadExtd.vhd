-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- loadExtd.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for the
--
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity load_extension is
   port(i_MemData   : in std_logic_vector(31 downto 0);  -- Raw data from memory
        i_Address   : in std_logic_vector(31 downto 0);  -- Memory address (for byte/halfword selection)
        i_funct3    : in std_logic_vector(2 downto 0);   -- Load type from instruction
        o_Extended  : out std_logic_vector(31 downto 0)); -- Extended output
end load_extension;

architecture behavioral of load_extension is
   signal byte_offset  : std_logic_vector(1 downto 0);
   signal half_offset  : std_logic;
   signal selected_byte : std_logic_vector(7 downto 0);
   signal selected_half : std_logic_vector(15 downto 0);
begin

   -- Extract offset from address
   byte_offset <= i_Address(1 downto 0);  -- Which byte (0-3)
   half_offset <= i_Address(1);           -- Which halfword (0-1)
   
   -- Select the appropriate byte based on address
   process(i_MemData, byte_offset)
   begin
      case byte_offset is
         when "00" => selected_byte <= i_MemData(7 downto 0);
         when "01" => selected_byte <= i_MemData(15 downto 8);
         when "10" => selected_byte <= i_MemData(23 downto 16);
         when "11" => selected_byte <= i_MemData(31 downto 24);
         when others => selected_byte <= (others => '0');
      end case;
   end process;
   
   -- Select the appropriate halfword based on address
   process(i_MemData, half_offset)
   begin
      case half_offset is
         when '0' => selected_half <= i_MemData(15 downto 0);
         when '1' => selected_half <= i_MemData(31 downto 16);
         when others => selected_half <= (others => '0');
      end case;
   end process;
   
   -- Extend based on load type (funct3)
   process(i_funct3, i_MemData, selected_byte, selected_half)
   begin
      case i_funct3 is
         when "000" =>  -- LB (load byte, sign-extend)
            if selected_byte(7) = '1' then
               o_Extended <= X"FFFFFF" & selected_byte;  -- Sign extend (negative)
            else
               o_Extended <= X"000000" & selected_byte;  -- Sign extend (positive)
            end if;
            
         when "001" =>  -- LH (load halfword, sign-extend)
            if selected_half(15) = '1' then
               o_Extended <= X"FFFF" & selected_half;    -- Sign extend (negative)
            else
               o_Extended <= X"0000" & selected_half;    -- Sign extend (positive)
            end if;
            
         when "010" =>  -- LW (load word, no extension)
            o_Extended <= i_MemData;
            
         when "100" =>  -- LBU (load byte unsigned, zero-extend)
            o_Extended <= X"000000" & selected_byte;
            
         when "101" =>  -- LHU (load halfword unsigned, zero-extend)
            o_Extended <= X"0000" & selected_half;
            
         when others => -- Default to full word
            o_Extended <= i_MemData;
      end case;
   end process;

end behavioral;