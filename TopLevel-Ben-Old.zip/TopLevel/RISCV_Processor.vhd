-------------------------------------------------------------------------
-- Henry Duwe
-- Department of Electrical and Computer Engineering
-- Iowa State University
-------------------------------------------------------------------------


-- RISCV_Processor.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: This file contains a skeleton of a RISCV_Processor  
-- implementation.

-- 01/29/2019 by H3::Design created.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

library work;
use work.RISCV_types.all;

entity RISCV_Processor is
  generic(N : integer := DATA_WIDTH);
  port(iCLK            : in std_logic;
       iRST            : in std_logic;
       iInstLd         : in std_logic;
       iInstAddr       : in std_logic_vector(N-1 downto 0);
       iInstExt        : in std_logic_vector(N-1 downto 0);
       oALUOut         : out std_logic_vector(N-1 downto 0)); -- TODO: Hook this up to the output of the ALU. It is important for synthesis that you have this output that can effectively be impacted by all other components so they are not optimized away.

end  RISCV_Processor;


architecture structure of RISCV_Processor is

  -- Required data memory signals
  signal s_DMemWr       : std_logic; -- TODO: use this signal as the final active high data memory write enable signal
  signal s_DMemAddr     : std_logic_vector(N-1 downto 0); -- TODO: use this signal as the final data memory address input
  signal s_DMemData     : std_logic_vector(N-1 downto 0); -- TODO: use this signal as the final data memory data input
  signal s_DMemOut      : std_logic_vector(N-1 downto 0); -- TODO: use this signal as the data memory output
 
  -- Required register file signals 
  signal s_RegWr        : std_logic; -- TODO: use this signal as the final active high write enable input to the register file
  signal s_RegWrAddr    : std_logic_vector(4 downto 0); -- TODO: use this signal as the final destination register address input
  signal s_RegWrData    : std_logic_vector(N-1 downto 0); -- TODO: use this signal as the final data memory data input

  -- Required instruction memory signals
  signal s_IMemAddr     : std_logic_vector(N-1 downto 0); -- Do not assign this signal, assign to s_NextInstAddr instead
  signal s_NextInstAddr : std_logic_vector(N-1 downto 0); -- TODO: use this signal as your intended final instruction memory address input.
  signal s_Inst         : std_logic_vector(N-1 downto 0); -- TODO: use this signal as the instruction signal 

  -- Required halt signal -- for simulation
  signal s_Halt         : std_logic;  -- TODO: this signal indicates to the simulation that intended program execution has completed. (Opcode: 01 0100)

  -- Required overflow signal -- for overflow exception detection
  signal s_Ovfl         : std_logic;  -- TODO: this signal indicates an overflow exception would have been initiated

  component mem is
    generic(ADDR_WIDTH : integer;
            DATA_WIDTH : integer);
    port(
          clk          : in std_logic;
          addr         : in std_logic_vector((ADDR_WIDTH-1) downto 0);
          data         : in std_logic_vector((DATA_WIDTH-1) downto 0);
          we           : in std_logic := '1';
          q            : out std_logic_vector((DATA_WIDTH -1) downto 0));
    end component;

  -- TODO: You may add any additional signals or components your implementation 
  --       requires below this comment

  -- Control signals from main_control
  signal s_ALUSrc       : std_logic;
  signal s_MemRead      : std_logic;
  signal s_MemtoReg     : std_logic_vector(1 downto 0);
  signal s_Branch       : std_logic;
  signal s_JAL          : std_logic;
  signal s_JALR         : std_logic;
  signal s_AUIPC        : std_logic;
  signal s_ALUOp        : std_logic_vector(2 downto 0);

  -- Signals from ALU_control
  signal s_ALUControl   : std_logic_vector(3 downto 0);

  -- Datapath signals
  signal s_RS1_Data     : std_logic_vector(N-1 downto 0);
  signal s_RS2_Data     : std_logic_vector(N-1 downto 0);
  signal s_ALU_Result   : std_logic_vector(N-1 downto 0);
  signal s_ALU_Zero     : std_logic;

  -- Immediate generation
  signal s_ImmExt       : std_logic_vector(N-1 downto 0);

  -- Fetch unit signals
  signal s_PC           : std_logic_vector(N-1 downto 0);
  signal s_PC_Plus4     : std_logic_vector(N-1 downto 0);
  signal s_BranchTaken  : std_logic;

  -- AUIPC signals
  signal s_AUIPC_Result : std_logic_vector(N-1 downto 0);

  -- Load extension signal
  signal s_DMemOut_Extended : std_logic_vector(N-1 downto 0);

  -- Instruction field extractions
  signal s_Opcode       : std_logic_vector(6 downto 0);
  signal s_funct3       : std_logic_vector(2 downto 0);
  signal s_funct7       : std_logic_vector(6 downto 0);
  signal s_RS1          : std_logic_vector(4 downto 0);
  signal s_RS2          : std_logic_vector(4 downto 0);
  signal s_RD           : std_logic_vector(4 downto 0);


---------- Component Declarations ----------
  -- Main control unit
  component main_control is
    port(i_opcode   : in std_logic_vector(6 downto 0);
         o_RegWrite : out std_logic;
         o_ALUSrc   : out std_logic;
         o_MemRead  : out std_logic;
         o_MemWrite : out std_logic;
         o_MemtoReg : out std_logic_vector(1 downto 0);
         o_Branch   : out std_logic;
         o_JAL      : out std_logic;
         o_JALR     : out std_logic;
         o_AUIPC    : out std_logic;
         o_Halt     : out std_logic;
         o_ALUOp    : out std_logic_vector(2 downto 0));
  end component;

  -- ALU control unit
  component ALU_control is
    port(i_ALUOp      : in std_logic_vector(2 downto 0);
         i_funct3     : in std_logic_vector(2 downto 0);
         i_funct7     : in std_logic_vector(6 downto 0);
         o_ALUControl : out std_logic_vector(3 downto 0));
  end component;

  -- Branch control unit
  component branch_control is
    port(i_Branch  : in  std_logic;
         i_funct3  : in  std_logic_vector(2 downto 0);
         i_Zero    : in  std_logic;
         i_ALURes0 : in  std_logic;
         o_TakeBr  : out std_logic);
  end component;

  -- Immediate generator
  component ImmGen is
    port(i_instr : in std_logic_vector(31 downto 0);
         o_imm   : out std_logic_vector(31 downto 0));
  end component;

  -- Register file based datapath
  component proj1_datapath is
    generic(N : integer := 32);
    port(i_CLK        : in std_logic;
         i_RST        : in std_logic;
         i_RegWE      : in std_logic;
         i_RD         : in std_logic_vector(4 downto 0);
         i_RS1        : in std_logic_vector(4 downto 0);
         i_RS2        : in std_logic_vector(4 downto 0);
         i_RegWrData  : in std_logic_vector(N-1 downto 0);
         i_ALUCtrl    : in std_logic_vector(3 downto 0);
         i_ALUSrc     : in std_logic;
         i_ImmExt     : in std_logic_vector(N-1 downto 0);
         o_RS1_Data   : out std_logic_vector(N-1 downto 0);
         o_RS2_Data   : out std_logic_vector(N-1 downto 0);
         o_ALU_Result : out std_logic_vector(N-1 downto 0);
         o_ALU_Zero   : out std_logic;
         o_Overflow   : out std_logic);
  end component;

  -- Fetch unit (PC management)
  component fetch is
    generic(WIDTH : integer := 32);
    port(iCLK          : in std_logic;
         i_RST         : in std_logic;
         i_WE          : in std_logic;
         i_BranchTaken : in std_logic;
         i_Jump        : in std_logic;
         i_JumpReg     : in std_logic;
         i_BranchImm   : in std_logic_vector(WIDTH-1 downto 0);
         i_JumpRegAddr : in std_logic_vector(WIDTH-1 downto 0);
         o_PC_Plus4    : out std_logic_vector(WIDTH-1 downto 0);
         o_PC          : out std_logic_vector(WIDTH-1 downto 0));
  end component;

  -- 4-to-1 MUX for write-back
  component mux4t1_N is
    generic(N : integer := 32);
    port(i_S  : in std_logic_vector(1 downto 0);
         i_D0 : in std_logic_vector(N-1 downto 0);
         i_D1 : in std_logic_vector(N-1 downto 0);
         i_D2 : in std_logic_vector(N-1 downto 0);
         i_D3 : in std_logic_vector(N-1 downto 0);
         o_O  : out std_logic_vector(N-1 downto 0));
  end component;

  -- Adder for AUIPC
  component full_adder_N is
     generic(N : integer := 32);
     port(i_N0    : in std_logic_vector(N-1 downto 0);
          i_N1    : in std_logic_vector(N-1 downto 0);
          i_Carry : in std_logic;
          o_Sum   : out std_logic_vector(N-1 downto 0);
          o_Carry : out std_logic);
  end component;

  -- Load extension for lb, lbu, lh, lhu
  component load_extension is
    port(i_MemData   : in std_logic_vector(31 downto 0);
         i_Address   : in std_logic_vector(31 downto 0);
         i_funct3    : in std_logic_vector(2 downto 0);
         o_Extended  : out std_logic_vector(31 downto 0));
  end component;

begin

  -- TODO: This is required to be your final input to your instruction memory. This provides a feasible method to externally load the memory module which means that the synthesis tool must assume it knows nothing about the values stored in the instruction memory. If this is not included, much, if not all of the design is optimized out because the synthesis tool will believe the memory to be all zeros.
  with iInstLd select
    s_IMemAddr <= s_NextInstAddr when '0',
      iInstAddr when others;

---------- Component/Signal Mapping ----------
  -- Instruction Memory
  IMem: mem
    generic map(ADDR_WIDTH => ADDR_WIDTH,
                DATA_WIDTH => N)
    port map(clk  => iCLK,
             addr => s_IMemAddr(11 downto 2),
             data => iInstExt,
             we   => iInstLd,
             q    => s_Inst);
  
  -- Data Memory
  DMem: mem
    generic map(ADDR_WIDTH => ADDR_WIDTH,
                DATA_WIDTH => N)
    port map(clk  => iCLK,
             addr => s_DMemAddr(11 downto 2),
             data => s_DMemData,
             we   => s_DMemWr,
             q    => s_DMemOut);

  -- TODO: Ensure that s_Halt is connected to an output control signal produced from decoding the Halt instruction (Opcode: 01 0100)
  -- TODO: Ensure that s_Ovfl is connected to the overflow output of your ALU

  -- TODO: Implement the rest of your processor below this comment!

  -- Load Extension Unit (for lb, lbu, lh, lhu)
  LOAD_EXT: load_extension
    port map(i_MemData  => s_DMemOut,
             i_Address  => s_DMemAddr,
             i_funct3   => s_funct3,
             o_Extended => s_DMemOut_Extended);

  ----- Extract Instr Fields -----
  s_Opcode <= s_Inst(6 downto 0);
  s_funct3 <= s_Inst(14 downto 12);
  s_funct7 <= s_Inst(31 downto 25);
  s_RS1    <= s_Inst(19 downto 15);
  s_RS2    <= s_Inst(24 downto 20);
  s_RD     <= s_Inst(11 downto 7);
  s_Halt <= '1' when s_Inst = X"10500073" else '0';
  
  -- Main control unit
  MAIN_CTRL: main_control
    port map(i_opcode   => s_Opcode,
             o_RegWrite => s_RegWr,
             o_ALUSrc   => s_ALUSrc,
             o_MemRead  => s_MemRead,
             o_MemWrite => s_DMemWr,
             o_MemtoReg => s_MemtoReg,
             o_Branch   => s_Branch,
             o_JAL      => s_JAL,
             o_JALR     => s_JALR,
             o_AUIPC    => s_AUIPC,
             o_Halt     => open,
             o_ALUOp    => s_ALUOp);

  -- ALU control unit
  ALU_CTRL: ALU_control
    port map(i_ALUOp      => s_ALUOp,
             i_funct3     => s_funct3,
             i_funct7     => s_funct7,
             o_ALUControl => s_ALUControl);

  -- Branch control unit
  BRANCH_CTRL: branch_control
    port map(i_Branch  => s_Branch,
             i_funct3  => s_funct3,
             i_Zero    => s_ALU_Zero,
             i_ALURes0 => s_ALU_Result(0),
             o_TakeBr  => s_BranchTaken);

  -- Immediate generator
  IMM_GEN: ImmGen
    port map(i_instr => s_Inst,
             o_imm   => s_ImmExt);


  -- Datapath (Reg file + ALU)
  DATAPATH: proj1_datapath
    generic map(N => N)
    port map(i_CLK        => iCLK,
             i_RST        => iRST,
             i_RegWE      => s_RegWr,
             i_RD         => s_RD,
             i_RS1        => s_RS1,
             i_RS2        => s_RS2,
             i_RegWrData  => s_RegWrData,
             i_ALUCtrl    => s_ALUControl,
             i_ALUSrc     => s_ALUSrc,
             i_ImmExt     => s_ImmExt,
             o_RS1_Data   => s_RS1_Data,
             o_RS2_Data   => s_RS2_Data,
             o_ALU_Result => s_ALU_Result,
             o_ALU_Zero   => s_ALU_Zero,
             o_Overflow   => s_Ovfl);

  -- Fetch unit
  FETCH_UNIT: fetch
    generic map(WIDTH => N)
    port map(iCLK          => iCLK,
             i_RST         => iRST,
             i_WE          => '1',
             i_BranchTaken => s_BranchTaken,
             i_Jump        => s_JAL,
             i_JumpReg     => s_JALR,
             i_BranchImm   => s_ImmExt,
             i_JumpRegAddr => s_ALU_Result,
             o_PC_Plus4    => s_PC_Plus4,
             o_PC          => s_PC);

  -- AUIPC Adder (PC + Immediate)
  AUIPC_ADDER: full_adder_N
    generic map(N => N)
    port map(i_N0    => s_PC,
             i_N1    => s_ImmExt,
             i_Carry => '0',
             o_Sum   => s_AUIPC_Result,
             o_Carry => open);

  -- Write back mux (4 to 1)
    ----------------------------------------------
    -- Selects data to write back to register file
    -- 00: ALU Result
    -- 01: Memory Data
    -- 10: PC+4 (for JAL/JALR)
    -- 11: AUIPC Result (PC + immediate)
    -----------------------------------------------
  WB_MUX: mux4t1_N
    generic map(N => N)
    port map(i_S  => s_MemtoReg,
             i_D0 => s_ALU_Result,
             i_D1 => s_DMemOut_Extended,
             i_D2 => s_PC_Plus4,
             i_D3 => s_AUIPC_Result,
             o_O  => s_RegWrData);

---------- Final Signal Connections ----------
  -- Connect memory address and data
  s_DMemAddr <= s_ALU_Result;
  s_DMemData <= s_RS2_Data;

  -- Connect register write address
  s_RegWrAddr <= s_RD;

  -- Connect PC to instruction memory address
  s_NextInstAddr <= s_PC;

  -- Connect ALU output to top-level output (required for synthesis)
  oALUOut <= s_ALU_Result;

end structure;

