-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- mux4t1_N.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for
-- 
-------------------------------------------------------------------------
library IEEE;
use IEEE.std_logic_1164.all;

entity mux4t1_N is
  generic(N : integer := 32);
  port(i_S   : in std_logic_vector(1 downto 0);  -- 2-bit select
       i_D0  : in std_logic_vector(N-1 downto 0); -- Input 0
       i_D1  : in std_logic_vector(N-1 downto 0); -- Input 1
       i_D2  : in std_logic_vector(N-1 downto 0); -- Input 2
       i_D3  : in std_logic_vector(N-1 downto 0); -- Input 3
       o_O   : out std_logic_vector(N-1 downto 0)); -- Output
end mux4t1_N;

architecture dataflow of mux4t1_N is
begin
  with i_S select
    o_O <= i_D0 when "00",   -- ALU Result
           i_D1 when "01",   -- Memory Data
           i_D2 when "10",   -- PC + 4 (for JAL/JALR)
           i_D3 when "11",   -- AUIPC Result (PC + immediate)
           (others => '0') when others;
end dataflow;