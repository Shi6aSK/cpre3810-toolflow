-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 381
-- Iowa State University
-------------------------------------------------------------------------

-- ones_comp.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file contains an implementation of a structural 
-- N-bit one's complement.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity ones_comp is
     generic (N : integer := 32);
     port(i_A   : in std_logic_vector(N-1 downto 0);
          o_F   : out std_logic_vector(N-1 downto 0));
end ones_comp;

architecture structural of ones_comp is
     component invg
          port(i_A   : in std_logic;
               o_F   : out std_logic);
     end component;

begin

   G_NBIT_ONES_COMP: for i in 0 to N-1 generate
     g_invg: invg
        port map(i_A   =>   i_A(i),
                 o_F   =>   o_F(i));
   end generate G_NBIT_ONES_COMP;
end structural;