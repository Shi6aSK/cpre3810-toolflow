-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- ALU_RISCV.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for the ALU
--
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity ALU_RISCV is
   port(i_opA      : in std_logic_vector(31 downto 0);
        i_opB      : in std_logic_vector(31 downto 0);
        i_ALUCtrl  : in std_logic_vector(3 downto 0);
        o_Result   : out std_logic_vector(31 downto 0);
        o_Zero     : out std_logic;
        o_Overflow : out std_logic);
end ALU_RISCV;

architecture structure of ALU_RISCV is
   signal s_addsub_result  : std_logic_vector(31 downto 0);
   signal s_addsub_carry   : std_logic;
   signal s_shift_result   : std_logic_vector(31 downto 0);
   signal s_result         : std_logic_vector(31 downto 0);
   signal s_control_addsub : std_logic;
   signal s_shift_dir      : std_logic;
   signal s_shift_arith    : std_logic;
   signal s_shift_amt      : std_logic_vector(4 downto 0);
   signal s_overflow       : std_logic;

   component add_sub_ctl is
      generic(N : integer := 32);
      port(i_X       : in std_logic_vector(N-1 downto 0);
           i_Y       : in std_logic_vector(N-1 downto 0);
           i_Control : in std_logic;
           o_Total   : out std_logic_vector(N-1 downto 0);
           o_Carry   : out std_logic);
   end component;

   component BarrelShifter is
      generic(N : integer := 32);
      port(i_S          : in std_logic_vector(4 downto 0);
           i_Data       : in std_logic_vector(N-1 downto 0);
           i_Dir        : in std_logic;
           i_Arith      : in std_logic;
           o_Output     : out std_logic_vector(N-1 downto 0));
   end component;

begin

   U_ADD_SUB : add_sub_ctl
      port map(i_X       => i_opA,
               i_Y       => i_opB,
               i_Control => s_control_addsub,
               o_Total   => s_addsub_result,
               o_Carry   => s_addsub_carry);

   s_shift_amt <= i_opB(4 downto 0);
   U_SHIFTER : BarrelShifter
      port map(i_S      => s_shift_amt,
               i_Data   => i_opA,
               i_Dir    => s_shift_dir,
               i_Arith  => s_shift_arith,
               o_Output => s_shift_result);

   process(i_opA, i_opB, i_ALUCtrl, s_addsub_result, s_shift_result, s_addsub_carry)
      variable signedA, signedB     : signed(31 downto 0);
      variable unsignedA, unsignedB : unsigned(31 downto 0);
   begin
      signedA   := signed(i_opA);
      signedB   := signed(i_opB);
      unsignedA := unsigned(i_opA);
      unsignedB := unsigned(i_opB);

      -- Set default values
      s_result         <= (others => '0');
      s_control_addsub <= '0';
      s_shift_dir      <= '0';
      s_shift_arith    <= '0';
      s_overflow       <= '0';  -- Default no overflow

      case i_ALUCtrl is
         -- Logical Operations
         when "0000" =>   -- AND
            s_result <= i_opA and i_opB;
            
         when "0001" =>   -- OR
            s_result <= i_opA or i_opB;
            
         when "0011" =>   -- XOR
            s_result <= i_opA xor i_opB;

         -- Arithmetic Operations
         when "0010" =>   -- ADD (R-type only - checks overflow)
            s_control_addsub <= '0';
            s_result <= s_addsub_result;
            -- Overflow detection for signed addition
            s_overflow <= (i_opA(31) and i_opB(31) and not s_addsub_result(31)) or
                         (not i_opA(31) and not i_opB(31) and s_addsub_result(31));
         
         when "0100" =>   -- ADDI (I-type - NO overflow check)
            s_control_addsub <= '0';
            s_result <= s_addsub_result;
            -- ADDI does not generate overflow exceptions in RISC-V
            s_overflow <= '0';
            
         when "0110" =>   -- SUB (R-type only - checks overflow)
            s_control_addsub <= '1';
            s_result <= s_addsub_result;
            -- Overflow detection for signed subtraction
            s_overflow <= (i_opA(31) and not i_opB(31) and not s_addsub_result(31)) or
                         (not i_opA(31) and i_opB(31) and s_addsub_result(31));

         -- Set less than (signed + unsigned)
         when "0111" =>   -- SLT (signed)
            s_control_addsub <= '1';
            if (signedA < signedB) then
               s_result <= (others => '0'); 
               s_result(0) <= '1';
            else
               s_result <= (others => '0');
            end if;
            
         when "1000" =>   -- SLTU (unsigned)
            s_control_addsub <= '1';
            if (unsignedA < unsignedB) then
               s_result <= (others => '0'); 
               s_result(0) <= '1';
            else
               s_result <= (others => '0');
            end if;

         -- Shifts
         when "1001" =>   -- SLL (shift left logical)
            s_shift_dir   <= '1';
            s_shift_arith <= '0';
            s_result      <= s_shift_result;
            
         when "1010" =>   -- SRL (shift right logical)
            s_shift_dir   <= '0';
            s_shift_arith <= '0';
            s_result      <= s_shift_result;
            
         when "1011" =>   -- SRA (shift right arithmetic)
            s_shift_dir   <= '0';
            s_shift_arith <= '1';
            s_result      <= s_shift_result;

         -- LUI / Pass B
         when "1100" =>   -- LUI
            s_result <= i_opB;
            
         when "1101" =>   -- PASS B
            s_result <= i_opB;

         -- HALT/NOP
         when "1111" =>   -- HALT
            s_result <= (others => '0');
            
         when others => 
            s_result <= (others => '0');
      end case;

   end process;

   -- Output assignments
   o_Result <= s_result;
   o_Zero <= '1' when s_result = X"00000000" else '0';
   o_Overflow <= s_overflow;

end structure;