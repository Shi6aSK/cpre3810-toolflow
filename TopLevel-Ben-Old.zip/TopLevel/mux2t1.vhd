-------------------------------------------------------------------------
-- Chingyam Yeung
-- Department of Electrical and Computer Engineering
-- Iowa State University
-------------------------------------------------------------------------


-- mux2t1.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: This file contain the 2 to 1 mux
--
--
-- NOTES:
-- Sep 4 designed
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity mux2t1 is

  port(
  	i_S             : in std_logic;
       i_D0	       : in std_logic;
       i_D1	       : in std_logic;
       o_O	       : out std_logic
  
  );

end mux2t1;

architecture Structural of mux2t1 is
  
component invg 
     port(i_A          : in std_logic;
     	  o_F          : out std_logic);
end component;

component andg2
     port(i_A          : in std_logic;
     	  i_B          : in std_logic;
     	  o_F          : out std_logic);
end component;

component org2
     port(i_A          : in std_logic;
          i_B          : in std_logic;
          o_F          : out std_logic);
end component;


  -- Signal to carry output of not gate
  signal s_inv        : std_logic;
  -- Signals to carry oupt of and gate1
  signal s_and1       : std_logic;
  -- Signal to carry output of and gate2
  signal s_and2       : std_logic;
  -- Signal to carry input of or gate
  signal s_or1       : std_logic;
  -- Signal to carry input of or gate
  signal s_or2       : std_logic;
--port map to their destination gate
begin 
not1: invg
     port Map(i_A => i_S, 
     	      o_F => s_inv);
     	 
and1: andg2
     port Map(i_A =>i_S, 
	      i_B =>i_D1,
	      o_F =>s_or1);   
	 
and2: andg2
     port Map(i_A =>s_inv, 
	      i_B =>i_D0,
	      o_F =>s_or2);     
	 
or1 : org2
     port Map(i_A =>s_or1, 
	      i_B =>s_or2,
	      o_F =>o_O);  	 
end Structural;
