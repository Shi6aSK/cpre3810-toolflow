-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 381
-- Iowa State University
-------------------------------------------------------------------------

-- full_adder_N.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file contains an implementation of a structural 
-- full adder for two N-bit inputs.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity full_adder_N is
     generic(N : integer := 32);
     port(i_N0    : in std_logic_vector(N-1 downto 0);
          i_N1    : in std_logic_vector(N-1 downto 0);
          i_Carry : in std_logic;
          o_Sum   : out std_logic_vector(N-1 downto 0);
          o_Carry : out std_logic);
end full_adder_N;

architecture structural of full_adder_N is
   component full_adder
      port(i_N0    : in std_logic;
           i_N1    : in std_logic;
           i_Carry : in std_logic;
           o_Sum   : out std_logic;
           o_Carry : out std_logic);
   end component;

   --Signal to connect carry from stage to stage
   signal carry : std_logic_vector(N downto 0);
   signal sum_internal : STD_LOGIC_VECTOR(N-1 downto 0);

begin
   carry(0) <= i_Carry;

   G_NBit_Adder: for i in 0 to N-1 generate
      FAdder : full_adder
         port map(i_N0    => i_N0(i),
                  i_N1    => i_N1(i),
                  i_Carry => carry(i),
                  o_Sum   => sum_internal(i),
                  o_Carry => carry(i+1));
   end generate G_NBit_Adder;

   o_Carry <= carry(N);

   o_Sum <= sum_internal;

end structural;