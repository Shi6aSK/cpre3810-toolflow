-------------------------------------------------------------------------
--Chingyam Yeung
-- Department of Electrical and Computer Engineering
-- Iowa State University
-------------------------------------------------------------------------
-- PC.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: This file contains an implementation of an PC
--
-- NOTES:
-- Oct 16 created
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity PC is
  generic(N : integer := 32); 
  port(i_CLK   : in std_logic;
       i_RST   : in std_logic;
       i_WE    : in std_logic;
       i_nextPC: in std_logic_vector(N-1 downto 0);
       o_PC    : out std_logic_vector(N-1 downto 0));
end PC;

architecture structural of PC is
  component nReg is
    generic(N : integer := 32);
    port(i_clock : in std_logic;
         i_reset : in std_logic;
         i_write : in std_logic;
         i_data  : in std_logic_vector(N-1 downto 0);
         o_data  : out std_logic_vector(N-1 downto 0));
  end component;
  
  constant PC_OFFSET : std_logic_vector(N-1 downto 0) := x"00400000";
  signal s_PC_internal : std_logic_vector(N-1 downto 0);
  signal s_nextPC_adjusted : std_logic_vector(N-1 downto 0);
  signal s_PC_adjusted : std_logic_vector(N-1 downto 0);
  
begin

  -- Subtract offset from input
  s_nextPC_adjusted <= std_logic_vector(unsigned(i_nextPC) - unsigned(PC_OFFSET));
  
  PC_reg : nReg
    generic map(N => N)
    port map(i_clock => i_CLK,
             i_reset => i_RST, 
             i_write => i_WE,
             i_data  => s_nextPC_adjusted, 
             o_data  => s_PC_internal);
  
  -- Add offset to output
  s_PC_adjusted <= std_logic_vector(unsigned(s_PC_internal) + unsigned(PC_OFFSET));
  o_PC <= s_PC_adjusted;
             
end structural;
