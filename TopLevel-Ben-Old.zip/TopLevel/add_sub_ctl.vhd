-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 381
-- Iowa State University
-------------------------------------------------------------------------

-- add_sub_ctl.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file contains an implementation of a structural 
-- two N-bit input adder/subtractor with control.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity add_sub_ctl is
     generic(N : integer := 32);
     port(i_X       : in std_logic_vector(N-1 downto 0);
          i_Y       : in std_logic_vector(N-1 downto 0);
          i_Control : in std_logic;
          o_Total     : out std_logic_vector(N-1 downto 0);
          o_Carry   : out std_logic);
end add_sub_ctl;

architecture Structural of add_sub_ctl is
   component ones_comp
      port(i_A   : in std_logic_vector(N-1 downto 0);
           o_F   : out std_logic_vector(N-1 downto 0));
   end component;

   component mux2t1_N
      port(i_S   : in std_logic;
           i_D0  : in std_logic_vector(N-1 downto 0);
           i_D1  : in std_logic_vector(N-1 downto 0);
           o_O   : out std_logic_vector(N-1 downto 0));
   end component;

   component full_adder_N
      port(i_N0    : in std_logic_vector(N-1 downto 0);
           i_N1    : in std_logic_vector(N-1 downto 0);
           i_Carry : in std_logic;
           o_Sum   : out std_logic_vector(N-1 downto 0);
           o_Carry : out std_logic);
   end component;

   signal Y_inverted : std_logic_vector(N-1 downto 0);
   signal Y_selected : std_logic_vector(N-1 downto 0);

begin
   INV: ones_comp
      port map (
         i_A => i_Y,
         o_F => Y_inverted
      );

   MUX: mux2t1_N
      port map (
         i_D0 => i_Y,
         i_D1 => Y_inverted,
         i_S => i_Control,
         o_O => Y_selected
      );

   ADDER: full_adder_N
      port map (
         i_N0 => i_X,
         i_N1 => Y_selected,
         i_Carry => i_Control,
         o_Sum => o_Total,
         o_Carry => o_Carry
      );

end Structural;