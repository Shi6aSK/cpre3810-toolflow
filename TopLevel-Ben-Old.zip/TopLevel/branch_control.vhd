------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- branch_control.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for
-- 
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

entity branch_control is
   port(i_Branch  : in  std_logic;
        i_funct3  : in  std_logic_vector(2 downto 0);
        i_Zero    : in  std_logic;
        i_ALURes0 : in  std_logic;  -- Bit 0 of ALU result (SLT/SLTU output)
        o_TakeBr  : out std_logic);
end branch_control;

architecture structure of branch_control is
begin
   process(i_Branch, i_funct3, i_Zero, i_ALURes0)
   begin
      o_TakeBr <= '0';
      if i_Branch = '1' then
         case i_funct3 is
            when "000" =>  -- BEQ
               o_TakeBr <= i_Zero;
               
            when "001" =>  -- BNE
               o_TakeBr <= not i_Zero;
               
            when "100" =>  -- BLT (signed)
               o_TakeBr <= i_ALURes0;  -- SLT result
               
            when "101" =>  -- BGE (signed)
               o_TakeBr <= not i_ALURes0;  -- NOT SLT result
               
            when "110" =>  -- BLTU (unsigned)
               o_TakeBr <= i_ALURes0;  -- SLTU result
               
            when "111" =>  -- BGEU (unsigned)
               o_TakeBr <= not i_ALURes0;  -- NOT SLTU result
               
            when others =>
               o_TakeBr <= '0';
         end case;
      end if;
   end process;
end structure;