library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity fetch is
  generic(WIDTH : integer := 32);
  port(
    iCLK          : in std_logic;
    i_RST         : in std_logic;
    i_WE          : in std_logic;
    i_BranchTaken : in std_logic;
    i_Jump        : in std_logic;
    i_JumpReg     : in std_logic;
    i_BranchImm   : in std_logic_vector(WIDTH-1 downto 0);
    i_JumpRegAddr : in std_logic_vector(WIDTH-1 downto 0);
    o_PC_Plus4    : out std_logic_vector(WIDTH-1 downto 0);
    o_PC          : out std_logic_vector(WIDTH-1 downto 0)
  );
end fetch;

architecture structure of fetch is

  component mux2t1_N
    generic(N : integer := 32);
    port(
       i_S  : in std_logic;
       i_D0 : in std_logic_vector(N-1 downto 0);
       i_D1 : in std_logic_vector(N-1 downto 0);
       o_O  : out std_logic_vector(N-1 downto 0)
    );
  end component;

  component PC
    generic(N : integer := 32);
    port(
      i_CLK    : in std_logic;
      i_RST    : in std_logic;
      i_WE     : in std_logic;
      i_nextPC : in std_logic_vector(N-1 downto 0);
      o_PC     : out std_logic_vector(N-1 downto 0)
    );
  end component;

  -- CHANGED: Using your actual adder component
  component full_adder_N is
    generic(N : integer := 32);
    port(i_N0    : in std_logic_vector(N-1 downto 0);
         i_N1    : in std_logic_vector(N-1 downto 0);
         i_Carry : in std_logic;
         o_Sum   : out std_logic_vector(N-1 downto 0);
         o_Carry : out std_logic);
  end component;

  signal s_PC            : std_logic_vector(WIDTH-1 downto 0);
  signal s_PC_Plus4      : std_logic_vector(WIDTH-1 downto 0);
  signal s_BranchTarget  : std_logic_vector(WIDTH-1 downto 0);
  signal s_Mux1_Out      : std_logic_vector(WIDTH-1 downto 0);
  signal s_Mux2_Out      : std_logic_vector(WIDTH-1 downto 0);
  signal s_NextPC        : std_logic_vector(WIDTH-1 downto 0);
  signal s_Cout          : std_logic;
  
  constant C_FOUR : std_logic_vector(WIDTH-1 downto 0) := x"00000004";

begin

  -- Output assignments
  o_PC       <= s_PC;
  o_PC_Plus4 <= s_PC_Plus4;

  -- Program Counter Register
  PC_inst: PC
    generic map(N => WIDTH)
    port map(
      i_CLK    => iCLK,
      i_RST    => i_RST,
      i_WE     => i_WE,
      i_nextPC => s_NextPC,
      o_PC     => s_PC
    );

  -- PC + 4 Adder (for sequential execution)
  -- CHANGED: Using your port names
  PC_Plus4_Adder: full_adder_N
    generic map(N => WIDTH)
    port map(
      i_N0    => s_PC,
      i_N1    => C_FOUR,
      i_Carry => '0',
      o_Carry => s_Cout,
      o_Sum   => s_PC_Plus4
    );

  -- Branch/Jump Target Adder (PC + Immediate)
  -- CHANGED: Using your port names
  Branch_Target_Adder: full_adder_N
    generic map(N => WIDTH)
    port map(
      i_N0    => s_PC,
      i_N1    => i_BranchImm,
      i_Carry => '0',
      o_Carry => open,  -- Don't care about carry out here
      o_Sum   => s_BranchTarget
    );

  -- MUX 1: Select between PC+4 and Branch/JAL target
  Mux_Branch_JAL: mux2t1_N
    generic map(N => WIDTH)
    port map(
      i_S  => i_BranchTaken or i_Jump,
      i_D0 => s_PC_Plus4,
      i_D1 => s_BranchTarget,
      o_O  => s_Mux1_Out
    );

  -- MUX 2: Select JALR target if JALR instruction
  Mux_JALR: mux2t1_N
    generic map(N => WIDTH)
    port map(
      i_S  => i_JumpReg,
      i_D0 => s_Mux1_Out,
      i_D1 => i_JumpRegAddr,
      o_O  => s_NextPC
    );

end structure;
