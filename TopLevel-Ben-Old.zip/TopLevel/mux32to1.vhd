-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- mux32to1.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for a dataflow design of
-- a 32 to 1 multiplexor
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity mux32to1 is
   port(i_Data   : in std_logic_vector(32*32-1 downto 0);
        i_Select : in std_logic_vector(4 downto 0);
        o_Data   : out std_logic_vector(31 downto 0));
end mux32to1;

architecture dataflow of mux32to1 is
   begin
      o_Data <= i_Data((to_integer(unsigned(i_Select))+1)*32-1 downto to_integer(unsigned(i_Select))*32);
end dataflow;