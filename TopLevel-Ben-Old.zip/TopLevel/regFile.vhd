-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- regFile.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the complete implementation of a RISC-V
-- based register file.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity regFile is
   port(i_CLK   : in std_logic;
        i_RST   : in std_logic;
        i_WE    : in std_logic;
        i_ADDR  : in std_logic_vector(4 downto 0);
        i_DATA  : in std_logic_vector(31 downto 0);
        i_RS1   : in std_logic_vector(4 downto 0);
        i_RS2   : in std_logic_vector(4 downto 0);
        o_RS1   : out std_logic_vector(31 downto 0);
        o_RS2   : out std_logic_vector(31 downto 0));
end regFile;

architecture structure of regFile is

   type reg_array_t is array (31 downto 0) of std_logic_vector(31 downto 0); -- Array of registers
   signal regs : reg_array_t := (others => (others => '0'));

   signal write_decode : std_logic_vector(31 downto 0); -- Unmasked one-hot decode

   signal we_vec : std_logic_vector(31 downto 0); -- Global wrtie enable, masked for x0

   signal din_flat : std_logic_vector(32*32-1 downto 0); -- Flattens bus for mux

   constant MASK_NO_X0 : std_logic_vector(31 downto 0) := (31 downto 1 => '1', 0 => '0'); -- Constant mask forces x0 to be zero

   signal rs1_data : std_logic_vector(31 downto 0);
   signal rs2_data : std_logic_vector(31 downto 0);

begin

   decode_inst : entity work.decoder_5to32
      port map(i_address  => i_ADDR,
               o_register => write_decode);

   we_vec <= (others => '0') when i_WE = '0' else (write_decode and MASK_NO_X0);

   gen_regs: for i in 0 to 31 generate
      u_reg: entity work.nReg
         generic map (N => 32)
         port map(i_clock => i_CLK,
                  i_reset => i_RST,
                  i_write => we_vec(i),
                  i_data  => i_DATA,
                  o_data  => regs(i));
   end generate gen_regs;

   gen_flatten: for i in 0 to 31 generate
      flatten_assign: process(regs(i))
      begin
         din_flat((i+1)*32-1 downto i*32) <= regs(i);
      end process;
   end generate gen_flatten;

   mux_rs1: entity work.mux32to1
      port map(i_Data   => din_flat,
               i_Select => i_RS1,
               o_Data   => rs1_data);

   mux_rs2: entity work.mux32to1
      port map(i_Data   => din_flat,
               i_Select => i_RS2,
               o_Data   => rs2_data);

   o_RS1 <= (others => '0') when i_RS1 = "00000" else rs1_data;
   o_RS2 <= (others => '0') when i_RS2 = "00000" else rs2_data;
end structure;