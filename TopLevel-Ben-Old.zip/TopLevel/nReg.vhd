-------------------------------------------------------------------------
-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- nReg.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file builds off an implementation of an edge-triggered
-- flip-flop with parallel access and reset in order to make an n-bit register
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

entity nReg is
    generic(N : integer := 32); 
    port (i_clock    : in std_logic;                         --Clock
	  i_reset    : in std_logic;		             --Reset
          i_write    : in std_logic;                         --Write enable
          i_data     : in std_logic_vector(N-1 downto 0);    --Data in
          o_data     : out std_logic_vector(N-1 downto 0));  --Data Out

end nReg;

architecture structural of nReg is 
  component dffg is
    port(i_CLK      : in std_logic;     -- Clock input
      	 i_RST      : in std_logic;     -- Reset input
       	 i_WE       : in std_logic;     -- Write enable input
       	 i_D        : in std_logic;     -- Data value input
       	 o_Q        : out std_logic);   -- Data value output
  end component;
 

begin

   G_NBit_REG: for i in 0 to N-1 generate
    dFFs : dffg port map(
           i_CLK  => i_clock,
           i_RST  => i_reset,
           i_WE   => i_write,
           i_D    => i_data(i),
           o_Q    => o_data(i));

   end generate G_NBit_REG;

end structural;
