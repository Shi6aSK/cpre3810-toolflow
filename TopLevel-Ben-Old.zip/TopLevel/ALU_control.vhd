-- Ben Boldog
-- Computer Engineering 3810
-- Iowa State University
-------------------------------------------------------------------------

-- ALU_control.vhd

-------------------------------------------------------------------------
-- DESCRIPTION: This file is the implementation for the ALU control unit
-- of the RISC-V style single cycle processor, determines exactly what 
-- types of instruction to perform based on ALUOp, funct7 and funct3.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

entity ALU_control is
   port(i_ALUOp      : in std_logic_vector(2 downto 0);
        i_funct3     : in std_logic_vector(2 downto 0);
        i_funct7     : in std_logic_vector(6 downto 0);
        o_ALUControl : out std_logic_vector(3 downto 0));
end ALU_control;

architecture structure of ALU_control is
begin
   process(i_ALUOp, i_funct3, i_funct7)
   begin
      o_ALUControl <= (others => '0');  -- Default
      
      case i_ALUOp is
         when "000" =>   -- Load/Store - Address calculation
            o_ALUControl <= "0100";   -- ADDI (no overflow)
            
         when "010" =>   -- R-Type (add, sub, and, or, xor, slt, sltu, sll, srl, sra)
            case i_funct3 is
               when "000" =>   -- ADD or SUB
                  if i_funct7 = "0100000" then
                     o_ALUControl <= "0110";   -- SUB
                  else
                     o_ALUControl <= "0010";   -- ADD (with overflow check)
                  end if;
                  
               when "111" =>   -- AND
                  o_ALUControl <= "0000";
                  
               when "110" =>   -- OR
                  o_ALUControl <= "0001";
                  
               when "100" =>   -- XOR
                  o_ALUControl <= "0011";
                  
               when "010" =>   -- SLT (signed)
                  o_ALUControl <= "0111";
                  
               when "011" =>   -- SLTU (unsigned)
                  o_ALUControl <= "1000";
                  
               when "001" =>   -- SLL (shift left logical)
                  o_ALUControl <= "1001";
                  
               when "101" =>   -- SRL or SRA
                  if i_funct7 = "0100000" then
                     o_ALUControl <= "1011";   -- SRA (arithmetic)
                  else
                     o_ALUControl <= "1010";   -- SRL (logical)
                  end if;
                  
               when others =>
                  o_ALUControl <= (others => '0');
            end case;
            
         when "011" =>   -- I-Type ALU (addi, andi, ori, xori, slti, sltiu, slli, srli, srai)
            case i_funct3 is
               when "000" =>   -- ADDI (NO overflow check)
                  o_ALUControl <= "0100";   -- CHANGED from "0010" to "0100"
                  
               when "111" =>   -- ANDI
                  o_ALUControl <= "0000";
                  
               when "110" =>   -- ORI
                  o_ALUControl <= "0001";
                  
               when "100" =>   -- XORI
                  o_ALUControl <= "0011";
                  
               when "010" =>   -- SLTI (signed)
                  o_ALUControl <= "0111";
                  
               when "011" =>   -- SLTIU (unsigned)
                  o_ALUControl <= "1000";
                  
               when "001" =>   -- SLLI (shift left logical immediate)
                  o_ALUControl <= "1001";
                  
               when "101" =>   -- SRLI or SRAI
                  if i_funct7(5) = '1' then  -- Check bit 30 of instruction (funct7[5])
                     o_ALUControl <= "1011";   -- SRAI (arithmetic)
                  else
                     o_ALUControl <= "1010";   -- SRLI (logical)
                  end if;
                  
               when others =>
                  o_ALUControl <= (others => '0');
            end case;
            
         when "110" =>   -- Branch (beq, bne, blt, bge, bltu, bgeu)
            case i_funct3 is
               when "000" =>   -- BEQ (subtract for zero flag)
                  o_ALUControl <= "0110";   -- SUB
                  
               when "001" =>   -- BNE (subtract for zero flag)
                  o_ALUControl <= "0110";   -- SUB
                  
               when "100" =>   -- BLT (signed less than)
                  o_ALUControl <= "0111";   -- SLT
                  
               when "101" =>   -- BGE (signed greater or equal)
                  o_ALUControl <= "0111";   -- SLT (branch control inverts)
                  
               when "110" =>   -- BLTU (unsigned less than)
                  o_ALUControl <= "1000";   -- SLTU
                  
               when "111" =>   -- BGEU (unsigned greater or equal)
                  o_ALUControl <= "1000";   -- SLTU (branch control inverts)
                  
               when others =>
                  o_ALUControl <= (others => '0');
            end case;
            
         when "111" =>   -- LUI
            o_ALUControl <= "1100";   -- Pass through immediate (not ADD!)
            
         when others =>
            o_ALUControl <= (others => '0');
      end case;
   end process;
end structure;